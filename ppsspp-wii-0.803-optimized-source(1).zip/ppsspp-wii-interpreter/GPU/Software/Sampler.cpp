// Copyright (c) 2017- PPSSPP Project.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2.0 or later versions.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License 2.0 for more details.

// A copy of the GPL 2.0 should have been included with the program.
// If not, see http://www.gnu.org/licenses/

// Official git repository and contact information can be found at
// https://github.com/hrydgard/ppsspp and http://www.ppsspp.org/.

#include <unordered_map>
#include <mutex>
#include "Common/ColorConv.h"
#include "Core/Reporting.h"
#include "GPU/Common/TextureDecoder.h"
#include "GPU/GPUState.h"
#include "GPU/Software/Sampler.h"
#if PPSSPP_PLATFORM(WII)
#include "Wii/BufferAccess.h"
#include "Wii/DXTTexel.h"
#endif

#if defined(_M_SSE)
#include <emmintrin.h>
#endif

using namespace Math3D;

extern u32 clut[4096];

namespace Sampler {

static u32 SampleNearest(int u, int v, const u8 *tptr, int bufw, int level);
static u32 SampleLinear(int u[4], int v[4], int frac_u, int frac_v, const u8 *tptr, int bufw, int level);

void Init() {}
void Shutdown() {}
static NearestFunc GetWiiNearestFunc();
static LinearFunc GetWiiLinearFunc();
NearestFunc GetNearestFunc() { return GetWiiNearestFunc(); }
LinearFunc GetLinearFunc() { return GetWiiLinearFunc(); }

template <unsigned int texel_size_bits, int swizzle = -1>
static inline int GetPixelDataOffset(unsigned int row_pitch_pixels, unsigned int u, unsigned int v)
{
	if (!(swizzle < 0 ? gstate.isTextureSwizzled() : bool(swizzle)))
		return (v * (row_pitch_pixels * texel_size_bits >> 3)) + (u * texel_size_bits >> 3);

	const int tile_size_bits = 32;
	const int tiles_in_block_horizontal = 4;
	const int tiles_in_block_vertical = 8;

	int texels_per_tile = tile_size_bits / texel_size_bits;
	int tile_u = u / texels_per_tile;
	int tile_idx = (v % tiles_in_block_vertical) * (tiles_in_block_horizontal) +
	// TODO: not sure if the *texel_size_bits/8 factor is correct
					(v / tiles_in_block_vertical) * ((row_pitch_pixels*texel_size_bits/(tile_size_bits))*tiles_in_block_vertical) +
					(tile_u % tiles_in_block_horizontal) +
					(tile_u / tiles_in_block_horizontal) * (tiles_in_block_horizontal*tiles_in_block_vertical);

	return tile_idx * (tile_size_bits / 8) + ((u % texels_per_tile) * texel_size_bits) / 8;
}

static inline u32 LookupColor(unsigned int index, unsigned int level)
{
	const bool mipmapShareClut = gstate.isClutSharedForMipmaps();
	const int clutSharingOffset = mipmapShareClut ? 0 : level * 16;

	switch (gstate.getClutPaletteFormat()) {
	case GE_CMODE_16BIT_BGR5650:
		return RGB565ToRGBA8888(reinterpret_cast<u16_le*>(clut)[index + clutSharingOffset]);

	case GE_CMODE_16BIT_ABGR5551:
		return RGBA5551ToRGBA8888(reinterpret_cast<u16_le*>(clut)[index + clutSharingOffset]);

	case GE_CMODE_16BIT_ABGR4444:
		return RGBA4444ToRGBA8888(reinterpret_cast<u16_le*>(clut)[index + clutSharingOffset]);

	case GE_CMODE_32BIT_ABGR8888:
		return reinterpret_cast<u32_le*>(clut)[index + clutSharingOffset];

	default:
		ERROR_LOG_REPORT(G3D, "Software: Unsupported palette format: %x", gstate.getClutPaletteFormat());
		return 0;
	}
}

struct Nearest4 {
	alignas(16) u32 v[4];

	operator u32() const {
		return v[0];
	}
};

static inline const u8 *TextureAccess(const u8 *base,unsigned offset,unsigned bytes) {
#if PPSSPP_PLATFORM(WII)
  alignas(16) static const u8 zero[16]{};
  const u8 *p=Wii::BufferAccess(const_cast<u8 *>(base),offset/bytes,0,0,bytes);
  return p?p:zero;
#else
  return base+offset;
#endif
}
template <int N, int format = -1, int swizzle = -1>
inline static Nearest4 SampleNearest(int u[N], int v[N], const u8 *srcptr, int texbufw, int level)
{
	Nearest4 res;
	if (!srcptr) {
		memset(res.v, 0, sizeof(res.v));
		return res;
	}

	GETextureFormat texfmt = format < 0 ? gstate.getTextureFormat() : GETextureFormat(format);

	// TODO: Should probably check if textures are aligned properly...

	switch (texfmt) {
	case GE_TFMT_4444:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<16, swizzle>(texbufw,u[i],v[i]),2);
			res.v[i] = RGBA4444ToRGBA8888(*(const u16_le *)src);
		}
		return res;
	
	case GE_TFMT_5551:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<16, swizzle>(texbufw,u[i],v[i]),2);
			res.v[i] = RGBA5551ToRGBA8888(*(const u16_le *)src);
		}
		return res;

	case GE_TFMT_5650:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<16, swizzle>(texbufw,u[i],v[i]),2);
			res.v[i] = RGB565ToRGBA8888(*(const u16_le *)src);
		}
		return res;

	case GE_TFMT_8888:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<32, swizzle>(texbufw,u[i],v[i]),4);
			res.v[i] = *(const u32_le *)src;
		}
		return res;

	case GE_TFMT_CLUT32:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<32, swizzle>(texbufw,u[i],v[i]),4);
			u32 val = *(u32_le *)src;
			res.v[i] = LookupColor(gstate.transformClutIndex(val), 0);
		}
		return res;

	case GE_TFMT_CLUT16:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<16, swizzle>(texbufw,u[i],v[i]),2);
			u16 val = *(u16_le *)src;
			res.v[i] = LookupColor(gstate.transformClutIndex(val), 0);
		}
		return res;

	case GE_TFMT_CLUT8:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<8, swizzle>(texbufw,u[i],v[i]),1);
			u8 val = *src;
			res.v[i] = LookupColor(gstate.transformClutIndex(val), 0);
		}
		return res;

	case GE_TFMT_CLUT4:
		for (int i = 0; i < N; ++i) {
			const u8 *src = TextureAccess(srcptr,GetPixelDataOffset<4, swizzle>(texbufw,u[i],v[i]),1);
			u8 val = (u[i] & 1) ? (src[0] >> 4) : (src[0] & 0xF);
			// Only CLUT4 uses separate mipmap palettes.
			res.v[i] = LookupColor(gstate.transformClutIndex(val), level);
		}
		return res;

	case GE_TFMT_DXT1:
		for (int i = 0; i < N; ++i) {
			const DXT1Block *block = (const DXT1Block *)TextureAccess(srcptr,((v[i]/4)*(texbufw/4)+(u[i]/4))*sizeof(DXT1Block),sizeof(DXT1Block));
#if PPSSPP_PLATFORM(WII)
			res.v[i] = Wii::DXTTexel(*block,u[i]%4,v[i]%4);
#else
			u32 data[4 * 4];
			DecodeDXT1Block(data, block, 4, 4, false);
			res.v[i] = data[4 * (v[i] % 4) + (u[i] % 4)];
#endif
		}
		return res;

	case GE_TFMT_DXT3:
		for (int i = 0; i < N; ++i) {
			const DXT3Block *block = (const DXT3Block *)TextureAccess(srcptr,((v[i]/4)*(texbufw/4)+(u[i]/4))*sizeof(DXT3Block),sizeof(DXT3Block));
#if PPSSPP_PLATFORM(WII)
			res.v[i] = Wii::DXTTexel(*block,u[i]%4,v[i]%4);
#else
			u32 data[4 * 4];
			DecodeDXT3Block(data, block, 4, 4);
			res.v[i] = data[4 * (v[i] % 4) + (u[i] % 4)];
#endif
		}
		return res;

	case GE_TFMT_DXT5:
		for (int i = 0; i < N; ++i) {
			const DXT5Block *block = (const DXT5Block *)TextureAccess(srcptr,((v[i]/4)*(texbufw/4)+(u[i]/4))*sizeof(DXT5Block),sizeof(DXT5Block));
#if PPSSPP_PLATFORM(WII)
			res.v[i] = Wii::DXTTexel(*block,u[i]%4,v[i]%4);
#else
			u32 data[4 * 4];
			DecodeDXT5Block(data, block, 4, 4);
			res.v[i] = data[4 * (v[i] % 4) + (u[i] % 4)];
#endif
		}
		return res;

	default:
		ERROR_LOG_REPORT(G3D, "Software: Unsupported texture format: %x", texfmt);
		memset(res.v, 0, sizeof(res.v));
		return res;
	}
}

static u32 SampleNearest(int u, int v, const u8 *tptr, int bufw, int level) {
	return SampleNearest<1>(&u, &v, tptr, bufw, level);
}

static u32 SampleLinear(int u[4], int v[4], int frac_u, int frac_v, const u8 *tptr, int bufw, int texlevel) {
	Nearest4 c = SampleNearest<4>(u, v, tptr, bufw, texlevel);

	Vec4<int> texcolor_tl = Vec4<int>::FromRGBA(c.v[0]);
	Vec4<int> texcolor_tr = Vec4<int>::FromRGBA(c.v[1]);
	Vec4<int> texcolor_bl = Vec4<int>::FromRGBA(c.v[2]);
	Vec4<int> texcolor_br = Vec4<int>::FromRGBA(c.v[3]);
	Vec4<int> t = texcolor_tl * (0x100 - frac_u) + texcolor_tr * frac_u;
	Vec4<int> b = texcolor_bl * (0x100 - frac_u) + texcolor_br * frac_u;
	return ((t * (0x100 - frac_v) + b * frac_v) / (256 * 256)).ToRGBA();
}

#if PPSSPP_PLATFORM(WII)
// Draw-time format/swizzle selection lets the C++ compiler remove per-texel
template<int format, int swizzle>
static u32 SampleNearestDirect(int u,int v,const u8 *p,int pitch,int level) {
  return SampleNearest<1,format,swizzle>(&u,&v,p,pitch,level);
}
template<int format, int swizzle>
static u32 SampleLinearDirect(int u[4], int v[4], int frac_u, int frac_v, const u8 *tptr, int bufw, int texlevel) {
	Nearest4 c = SampleNearest<4,format,swizzle>(u, v, tptr, bufw, texlevel);

	Vec4<int> texcolor_tl = Vec4<int>::FromRGBA(c.v[0]);
	Vec4<int> texcolor_tr = Vec4<int>::FromRGBA(c.v[1]);
	Vec4<int> texcolor_bl = Vec4<int>::FromRGBA(c.v[2]);
	Vec4<int> texcolor_br = Vec4<int>::FromRGBA(c.v[3]);
	Vec4<int> t = texcolor_tl * (0x100 - frac_u) + texcolor_tr * frac_u;
	Vec4<int> b = texcolor_bl * (0x100 - frac_u) + texcolor_br * frac_u;
	return ((t * (0x100 - frac_v) + b * frac_v) / (256 * 256)).ToRGBA();
}

static NearestFunc GetWiiNearestFunc() {
  const bool swizzle=gstate.isTextureSwizzled();
#define WII_NEAREST(fmt) case fmt: return swizzle ? &SampleNearestDirect<fmt,1> : &SampleNearestDirect<fmt,0>
  switch(gstate.getTextureFormat()) {
    WII_NEAREST(GE_TFMT_5650); WII_NEAREST(GE_TFMT_5551);
    WII_NEAREST(GE_TFMT_4444); WII_NEAREST(GE_TFMT_8888);
    default: return &SampleNearest;
  }
#undef WII_NEAREST
}
static LinearFunc GetWiiLinearFunc() {
  const bool swizzle=gstate.isTextureSwizzled();
#define WII_LINEAR(fmt) case fmt: return swizzle ? &SampleLinearDirect<fmt,1> : &SampleLinearDirect<fmt,0>
  switch(gstate.getTextureFormat()) {
    WII_LINEAR(GE_TFMT_5650); WII_LINEAR(GE_TFMT_5551);
    WII_LINEAR(GE_TFMT_4444); WII_LINEAR(GE_TFMT_8888);
    default: return &SampleLinear;
  }
#undef WII_LINEAR
}
#endif

};
